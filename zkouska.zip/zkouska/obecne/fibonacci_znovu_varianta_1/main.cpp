//vypis X prvku fibonacciho posloupnosti
#include <iostream>


int main()
{
    int x=1;
    int pom2=1;
    int prom=0;
    for (int i=0;i<=x;i++){
        if (i==0){
            if (i==0){
                std::cout<<i<<". prvek fibonacciho posloupnosti je "<<0<<std::endl;
            }
        }else{
            prom=pom2+prom;
            pom2=prom-pom2;
            std::cout<<i<<". prvek fibonacciho posloupnosti je "<<prom<<std::endl;
        }
    }
}
