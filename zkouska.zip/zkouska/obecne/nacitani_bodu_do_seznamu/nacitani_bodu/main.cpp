#include <iostream>
#include <vector>

//načtení seznamu souřadnic
struct bod{
    double x;
    double y;
};
int poc;

int main()
{
std::cout<<"Kolik bodu bude v seznamu:"<<std::endl;
std::cin>>poc;

std::vector <bod> vec(poc);
for(int i=0; i<=poc-1;i++){
    int y=i+1;
    std::cout<<"Zadejte souradnice bodu [x,y] cislo: "<<y<<std::endl;
    std::cin>>vec[i].x;
    std::cin>>vec[i].y;
}
}
