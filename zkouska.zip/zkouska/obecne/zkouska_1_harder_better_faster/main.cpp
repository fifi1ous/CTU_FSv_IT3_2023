#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include "moje_struktury.h"
#include "funkce_teziste.h"
#include "funkce_nejvd_bod.h"


//void nejv_bod(std::vector <BOD> SS,BOD T,BOD &N);
//void teziste (std::vector <BOD> SS, BOD &T);

int main()
{
    std::cout<<"Napiste souradnice bodu [X Y]:"<<std::endl;
    std::vector <BOD> SS;
    BOD b;
    while (std::cin>>b.x>>b.y){
        SS.push_back(b);
    }

    BOD T={0,0};
    BOD N;

    //teziste
    teziste (SS,T);


    std::cout<<"Souradnice teziste [X Y] jsou: "<< std::setprecision(4)<< T.x<<" "<<std::setprecision(4)<<T.y<<std::endl;

    //nejvzdalenejsi bod
    nejv_bod(SS, T, N);

    std::cout<<"\nSouradnice nejvzdalenejsiho bodu [X Y] jsou: "<< std::setprecision(4)<< N.x<<" "<<std::setprecision(4)<<N.y<<std::endl;

}

/*void nejv_bod(std::vector <BOD> SS,BOD T,BOD &N){
    double max_vzd=std::sqrt((T.x-SS[0].x)*(T.x-SS[0].x)+(T.y-SS[0].y)*(T.y-SS[0].y));
    int poc=SS.size();
    N.x=SS[0].x;
    N.y=SS[0].y;
    for (int i=1;i<poc;i++){
        double vzd = std::sqrt((T.x-SS[i].x)*(T.x-SS[i].x)+(T.y-SS[i].y)*(T.y-SS[i].y));
        if (max_vzd<vzd){
            max_vzd=vzd;
            N.x=SS[i].x;
            N.y=SS[i].y;
        }
    }
}*/

/*void teziste (std::vector <BOD> SS, BOD &T){
    int poc=SS.size();
    for (int i=0;i<poc;i++){
        T.x+=SS[i].x;
        T.y+=SS[i].y;
    }
    T.x/=poc;
    T.y/=poc;

}*/

