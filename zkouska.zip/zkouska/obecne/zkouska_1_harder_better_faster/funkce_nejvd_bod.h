#ifndef FUNKCE_NEJVD_BOD_H
#define FUNKCE_NEJVD_BOD_H

#include <vector>
#include "moje_struktury.h"

void nejv_bod(std::vector <BOD> SS,BOD T,BOD &N);

#endif // FUNKCE_NEJVD_BOD_H
