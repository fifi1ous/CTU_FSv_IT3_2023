#ifndef FUNKCE_TEZISTE_H
#define FUNKCE_TEZISTE_H

#include "moje_struktury.h"
#include <vector>

void teziste (std::vector <BOD> SS, BOD &T);

#endif // FUNKCE_TEZISTE_H
