#include "funkce_nejvd_bod.h"
#include <vector>
#include <cmath>

void nejv_bod(std::vector <BOD> SS,BOD T,BOD &N){
    double max_vzd=std::sqrt((T.x-SS[0].x)*(T.x-SS[0].x)+(T.y-SS[0].y)*(T.y-SS[0].y));
    int poc=SS.size();
    N.x=SS[0].x;
    N.y=SS[0].y;
    for (int i=1;i<poc;i++){
        double vzd = std::sqrt((T.x-SS[i].x)*(T.x-SS[i].x)+(T.y-SS[i].y)*(T.y-SS[i].y));
        if (max_vzd<vzd){
            max_vzd=vzd;
            N.x=SS[i].x;
            N.y=SS[i].y;
        }
    }
}
