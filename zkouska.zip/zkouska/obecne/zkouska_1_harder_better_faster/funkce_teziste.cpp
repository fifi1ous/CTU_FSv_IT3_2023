#include "funkce_teziste.h"
#include <iostream>
#include <vector>

void teziste (std::vector <BOD> SS, BOD &T){
    int poc=SS.size();
    for (int i=0;i<poc;i++){
        T.x+=SS[i].x;
        T.y+=SS[i].y;
    }
    T.x/=poc;
    T.y/=poc;

}
