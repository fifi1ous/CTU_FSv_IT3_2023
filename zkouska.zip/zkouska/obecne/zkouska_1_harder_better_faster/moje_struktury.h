#ifndef MOJE_STRUKTURY_H
#define MOJE_STRUKTURY_H


struct BOD{
    double x;
    double y;
};


#endif // MOJE_STRUKTURY_H
