#include <iostream>
#include <vector>
#include <cmath>
#include "moje_struktury.h"
#include "funkce_teziste.h"
#include "funkce_vzdalenost.h"


int main()
{
    std::vector <t> SS={t{10,5},t{-6,-1},t{-5,2}};
    t T;
    t B;
    vypocet_teziste(SS,T);
    std::cout<<"Souradnice teziste:  X: "<<T.x<<" Y: "<<T.y<<std::endl;

    int poc=SS.size();
    double min_vzd=vzdalenost(T, SS[0]);
    B.x=SS[0].x; B.y=SS[0].y;
    for (int i=1;i<poc;i++){
        if (min_vzd>=vzdalenost(T, SS[i])){
            min_vzd=vzdalenost(T, SS[i]);
            B.x=SS[i].x;
            B.y=SS[i].y;
        }
    }
    std::cout<<"Souradnice bodu co je nejbliz:  X: "<<B.x<<" B: "<<B.y<<std::endl;

}


