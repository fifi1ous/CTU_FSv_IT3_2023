#ifndef FUNKCE_VZDALENOST_H
#define FUNKCE_VZDALENOST_H

#include <iostream>
#include <vector>
#include <cmath>
#include "moje_struktury.h"

double vzdalenost(t A, t B);

#endif // FUNKCE_VZDALENOST_H
