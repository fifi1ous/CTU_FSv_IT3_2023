#include "funkce_teziste.h"
#include <iostream>
#include <vector>

void vypocet_teziste(std::vector <t> SS, t &T){
    int poc=SS.size();
    T.x=0;      T.y=0;

    for (int i=0;i<poc;i++){
        T.x+=SS[i].x;
        T.y+=SS[i].y;
    }

    T.x/=poc;   T.y/=poc;
}
