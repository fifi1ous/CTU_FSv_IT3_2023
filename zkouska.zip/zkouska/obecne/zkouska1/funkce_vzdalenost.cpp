#include "funkce_vzdalenost.h"
#include <iostream>
#include <vector>
#include <cmath>

double vzdalenost(t A, t B){
    return std::sqrt((A.x-B.x)*(A.x-B.x)+(A.y-B.y)*(A.y-B.y));
}
