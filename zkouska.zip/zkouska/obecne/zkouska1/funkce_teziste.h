#ifndef FUNKCE_TEZISTE_H
#define FUNKCE_TEZISTE_H
#include <iostream>
#include <vector>
#include "moje_struktury.h"

void vypocet_teziste(std::vector <t> SS, t &T);

#endif // FUNKCE_TEZISTE_H
