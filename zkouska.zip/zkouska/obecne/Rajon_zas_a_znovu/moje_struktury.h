#ifndef MOJE_STRUKTURY_H
#define MOJE_STRUKTURY_H

struct BOD{
    double x;
    double y;
};

struct mereni{
    double d;
    double s;
};

#endif // MOJE_STRUKTURY_H
