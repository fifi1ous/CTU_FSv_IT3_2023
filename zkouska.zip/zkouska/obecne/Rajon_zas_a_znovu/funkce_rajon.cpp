#include <cmath>
#include "funkce_rajon.h"

void rajon(BOD st, std::vector <mereni> ZAP,std::vector <BOD> &SS){
    int poc=ZAP.size();
    double prevod=M_PI/200;
    for(int i=0;i<poc;i++){
        SS[i].x=st.x+ZAP[i].d*std::cos(ZAP[0].s*prevod);
        SS[i].y=st.y+ZAP[i].d*std::sin(ZAP[0].s*prevod);
    }
}
