#ifndef FUNKCE_RAJON_H
#define FUNKCE_RAJON_H
#include "moje_struktury.h"
#include <vector>

void rajon(BOD st, std::vector <mereni> ZAP,std::vector <BOD> &SS);

#endif // FUNKCE_RAJON_H
