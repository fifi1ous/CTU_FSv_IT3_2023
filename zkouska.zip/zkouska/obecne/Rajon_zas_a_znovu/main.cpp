#include <iostream>
#include <vector>
#include <cmath>
#include "moje_struktury.h"
#include "funkce_rajon.h"

int main()
{
    BOD st;
    std::cout<<"Zadejte souradnice stanoviska [X Y]"<<std::endl;
    std::cin>>st.x>>st.y;

    std::cout<<"Zadejte mereni delka[m] smer[g]"<<std::endl;
    std::vector <mereni> ZAP;
    mereni m;
    while(std::cin>>m.d>>m.s){
        ZAP.push_back(m);
    }

    int a=ZAP.size();
    std::vector <BOD> SS(a);

    rajon(st,ZAP,SS);

    for (int i=0;i<a;i++){
        std::cout<<SS[i].x<<" "<<SS[i].y<<std::endl;
    }
}


