#ifndef FUNKCE_PRVOCISLO_H
#define FUNKCE_PRVOCISLO_H

#include <iostream>

void pvocislo(int x);

#endif // FUNKCE_PRVOCISLO_H
