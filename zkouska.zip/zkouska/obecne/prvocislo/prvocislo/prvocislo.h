#ifndef PRVOCISLO_H
#define PRVOCISLO_H
#include <iostream>

#endif // PRVOCISLO_H
