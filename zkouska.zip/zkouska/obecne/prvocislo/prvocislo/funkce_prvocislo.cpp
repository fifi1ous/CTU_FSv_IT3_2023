#include "funkce_prvocislo.h"
#include <iostream>

void pvocislo(int x){
    int y=1;
    if (x>1){
    for(int i=2;i<x/2;i++){
        if (x%i==0){
            std::cout<<"Cislo "<<x<<" neni prvocislo"<<std::endl;
            y=0;
            break;
        }
    }
    if (y){
       std::cout<<"Cislo "<<x<<" je prvocislo"<<std::endl;
    }
    }else{
       std::cout<<"Cislo "<<x<<" nesplnuje pozadavky pro to byt prvocislo"<<std::endl;
    }
}
