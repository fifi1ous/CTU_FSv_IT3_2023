#include <iostream>
#include <vector>
#include "sort_descendant.h"

std::vector <int> x={9,1,2,3,5,11,7,1,3};
//void sort_descendant(std::vector<int> &x);
//int pom;
int main()
{

int a=x.size();

/*for(int i=0;i<a-1;i++){
    for(int j=0;j<a-i;j++){
        if (x[j]<x[j+1]){
            pom=x[j];
            x[j]=x[j+1];
            x[j+1]=pom;
        }
    }
}*/
sort_descendant(x);

for (int i=0; i<=a-1;i++){
    std::cout<<x[i]<<" ";
}
}

/*void sort_descendant(std::vector<int> &x){
    int a=x.size();
    for(int i=0;i<a-1;i++){
        for(int j=0;j<a-i;j++){
            if (x[j]<x[j+1]){
                pom=x[j];
                x[j]=x[j+1];
                x[j+1]=pom;
            }
        }
    }
}*/

