#include "sort_descendant.h"
#include <iostream>
#include <vector>

int pom;
void sort_descendant(std::vector<int> &x){
    int a=x.size();
    for(int i=0;i<a-1;i++){
        for(int j=0;j<a-i;j++){
            if (x[j]<x[j+1]){
                pom=x[j];
                x[j]=x[j+1];
                x[j+1]=pom;
            }
        }
    }
}
