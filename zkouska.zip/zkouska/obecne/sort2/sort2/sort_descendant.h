#ifndef SORT_DESCENDANT_H
#define SORT_DESCENDANT_H

#include <iostream>
#include <vector>
void sort_descendant(std::vector<int> &x);

#endif // SORT_DESCENDANT_H
