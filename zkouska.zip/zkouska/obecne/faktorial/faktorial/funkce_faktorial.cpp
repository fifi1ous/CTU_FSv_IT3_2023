#include "funkce_faktorial.h"
#include <iostream>

int faktorial(int x){
int vys=1;
for (x;x>1;x--){
    vys*=x;
}
return vys;
}
