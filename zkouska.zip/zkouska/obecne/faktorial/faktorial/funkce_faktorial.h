#ifndef FUNKCE_FAKTORIAL_H
#define FUNKCE_FAKTORIAL_H

#include <iostream>
int faktorial(int x);

#endif // FUNKCE_FAKTORIAL_H
