#include <iostream>
#include "funkce_faktorial.h"
int x;
int vys = 1;

//int faktorial(int x);

int main()
{
std::cout<<"Vlozte cislo pro ktere chcete udelat faktorial:"<<std::endl;
std::cin>>x;

/*for (x;x>1;x--){
    vys*=x;
}*/

std::cout<<"Faktorial cisla "<<x<<" je: "<<faktorial(x)<<std::endl;
}

/*int faktorial(int x){
int vys=1;
for (x;x>1;x--){
    vys*=x;
}
return vys;
}*/

