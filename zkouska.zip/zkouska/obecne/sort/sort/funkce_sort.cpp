#include "funkce_sort.h"
#include <iostream>
#include <vector>

void sort(std::vector<int>&a){
    int pom;
    int x=a.size();
    for (int n=1;n<=(x-1);n++){
        for (int m=0;m<=(x-n)-1;m++){
            if (a[m]>a[m+1]){
                pom=a[m];
                a[m]=a[m+1];
                a[m+1]=pom;
            }
        }
    }
}
