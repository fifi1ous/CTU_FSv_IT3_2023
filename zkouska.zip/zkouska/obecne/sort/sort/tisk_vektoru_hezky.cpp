#include "tisk_vektoru_hezky.h"
#include <iostream>
#include <vector>

void tisk_vektoru(std::vector<int>a){
    int x=a.size();
    std::cout<<"[";
    for(int i=0;i<=(x-2);i++){
    std::cout<<a[i];
    std::cout<<" ";
    }
    std::cout<<a[x-1];
    std::cout<<"]"<<std::endl;
}
