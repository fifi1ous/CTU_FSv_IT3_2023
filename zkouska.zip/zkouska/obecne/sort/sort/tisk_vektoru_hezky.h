#ifndef TISK_VEKTORU_HEZKY_H
#define TISK_VEKTORU_HEZKY_H

#include <iostream>
#include <vector>
void tisk_vektoru(std::vector<int>a);

#endif // TISK_VEKTORU_HEZKY_H
