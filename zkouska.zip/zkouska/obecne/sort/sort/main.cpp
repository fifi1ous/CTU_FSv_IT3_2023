#include <iostream>
#include <vector>
#include "funkce_sort.h"
#include "tisk_vektoru_hezky.h"

// seřazení prvků ve vektoru
int x;
int pom;

/*void tisk_vektoru(std::vector<int>a);*/
/*void sort(std::vector<int>&a);*/

int main()
{
std::cout<<"Kolik prvku bude mit vektor:";
std::cin>>x;
std::cout<<std::endl;
std::vector<int>a(x);
std::cout<<"Zadejte prvky vektoru:"<<std::endl;
for(int i=0;i<=(x-1);i++){
std::cin>>a[i];
}

sort(a);
std::cout<<"\nVysledny vektor:"<<std::endl;
tisk_vektoru(a);

}
/*void sort(std::vector<int>&a){
    int pom;
    int x=a.size();
    for (int n=1;n<=(x-1);n++){
        for (int m=0;m<=(x-n)-1;m++){
            if (a[m]>a[m+1]){
                pom=a[m];
                a[m]=a[m+1];
                a[m+1]=pom;
            }
        }
    }
}*/


/*void tisk_vektoru(std::vector<int>a){
    std::cout<<"[";
    for(int i=0;i<=(x-2);i++){
    std::cout<<a[i];
    std::cout<<" ";
    }
    std::cout<<a[x-1];
    std::cout<<"]"<<std::endl;
}*/
