#ifndef FUNKCE_SORT_H
#define FUNKCE_SORT_H


# include <vector>

void sort(std::vector<int>&a);

#endif // FUNKCE_SORT_H
