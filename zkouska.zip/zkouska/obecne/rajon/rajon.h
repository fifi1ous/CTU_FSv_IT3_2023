#ifndef RAJON_H
#define RAJON_H

#include <iostream>
#include <vector>
#include <cmath>
#include "moje_struktury.h"


void rajon(ST st,std::vector <mereni> x,std::vector <SS> &ss);

#endif // RAJON_H
