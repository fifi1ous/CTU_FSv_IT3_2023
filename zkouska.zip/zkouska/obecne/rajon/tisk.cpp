#include "tisk.h"
#include <iostream>
#include <vector>
#include <cmath>

void tisk(std::vector <SS> ss){
    int poc=ss.size();
    std::cout<<"\nSeznam souradnic: CB   X[m]   Y[m]"<<std::endl;
    for (int i=0;i<poc;i++){
        std::cout<<ss[i].CB<<"  "<<ss[i].x<<"  "<<ss[i].y<<std::endl;
    }
}
