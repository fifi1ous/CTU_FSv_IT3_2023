#ifndef TISK_H
#define TISK_H

#include <iostream>
#include <vector>
#include <cmath>
#include "moje_struktury.h"



void tisk(std::vector <SS> ss);

#endif // TISK_H
