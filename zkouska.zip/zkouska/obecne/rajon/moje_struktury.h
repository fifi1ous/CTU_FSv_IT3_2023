#ifndef MOJE_STRUKTURY_H
#define MOJE_STRUKTURY_H

struct ST{
    double x;
    double y;
};
struct SS{
    int CB;
    double x;
    double y;
};
struct mereni{
    double d;
    double s;
};

#endif // MOJE_STRUKTURY_H
