#include "rajon.h"
#include <iostream>
#include <vector>
#include <cmath>


void rajon(ST st,std::vector <mereni> x,std::vector <SS> &ss){
    int poc=x.size();
    int cb;
    double prev=M_PI/200;
    for (int i=0;i<poc;i++){
        cb=i+1;
        ss[i].CB=cb;
        ss[i].x=st.x+x[i].d*std::cos(x[i].s*prev);
        ss[i].y=st.y+x[i].d*std::sin(x[i].s*prev);
    }
}
