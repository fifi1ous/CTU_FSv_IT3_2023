#include <iostream>
#include <vector>
#include <cmath>
#include "rajon.h"
#include "moje_struktury.h"
#include "tisk.h"

/*struct ST{
    double x;
    double y;
};
struct SS{
    int CB;
    double x;
    double y;
};
struct mereni{
    double d;
    double s;
};*/

//void rajon(ST st,std::vector <mereni> x,std::vector <SS> &ss);
//void tisk(std::vector <SS> ss);

int main()
{
    int poc;
    std::cout<<"Kolik bodu bylo mereno: ";
    std::cin>>poc;
    std::cout<<std::endl;

    std::cout<<"Zadejte souradnice stanoviska [x y]:"<<std::endl;
    ST st;
    std::cin>>st.x;
    std::cin>>st.y;

    std::vector <mereni> x(poc);
    std::cout<<"\nZadejte mereni na body delka[m] smer[g]:"<<std::endl;
    for (int i=0;i<poc;i++){
        std::cin>>x[i].d;
        std::cin>>x[i].s;
    }

    std::vector <SS> ss(poc);

    rajon(st,x,ss);
    tisk(ss);

}

/*void rajon(ST st,std::vector <mereni> x,std::vector <SS> &ss){
    int poc=x.size();
    int cb;
    double prev=M_PI/200;
    for (int i=0;i<poc;i++){
        cb=i+1;
        ss[i].CB=cb;
        ss[i].x=st.x+x[i].d*std::cos(x[i].s*prev);
        ss[i].y=st.y+x[i].d*std::sin(x[i].s*prev);
    }
}*/

/*void tisk(std::vector <SS> ss){
    int poc=ss.size();
    std::cout<<"\nSeznam souradnic: CB   X[m]   Y[m]"<<std::endl;
    for (int i=0;i<poc;i++){
        std::cout<<ss[i].CB<<"  "<<ss[i].x<<"  "<<ss[i].y<<std::endl;
    }
}*/
