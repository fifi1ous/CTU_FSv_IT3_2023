#include <iostream>

// vypiš x tý prvek fibonaciho posloupnosti
int x;
int st=1;
int pom1;
int pom2;
int vypis;
int y;

int main()
{
//std::cin>>x;
x=40;
if (x==0){
    std::cout<<"Hodnota Fibonacciho posloupnosti na "<<x<<". prvku je: "<<"0"<<std::endl;
}else{
    if (x==1){
    std::cout<<"Hodnota Fibonacciho posloupnosti na "<<x<<". prvku je: "<<"1"<<std::endl;
    }else{
    y=x;
    while(y>1){
        pom1=st;
        st=pom2+st;
        pom2=pom1;
        y--;
    }
    vypis=st;
    std::cout<<"Hodnota Fibonacciho posloupnosti na "<<x<<". prvku je: "<<vypis<<std::endl;
}
}

}
