//Fibonaciho posloupnost vypis x ty prvek
#include <iostream>


int main()
{
    int x=10;
    int pom=1;
    int prom=0;
    int i=0;
    for (int i=0;i<=x;i++){
        if (x==0){
            std::cout<<x<<". prvek Fibonacciho posloupnosti je 0"<<std::endl;
        }else{
            prom=prom+pom;
            pom=prom-pom;
            if (i==x-1){
                std::cout<<x<<". prvek Fibonacciho posloupnosti je "<<prom<<std::endl;
            }
        }
    }
}
