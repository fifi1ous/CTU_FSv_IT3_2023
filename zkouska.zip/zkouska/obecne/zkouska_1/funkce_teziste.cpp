#include "funkce_teziste.h"
#include <iostream>
#include <vector>
#include "moje_struktury.h"

void vypocet_teziste(std::vector <ss> SS, t &T){
    int poc=SS.size();
    for (int i=0;i<poc;i++){
        T.x+=SS[i].x;
        T.y+=SS[i].y;
    }
    T.x=T.x/poc;
    T.y=T.y/poc;
}


