#ifndef MOJE_STRUKTURY_H
#define MOJE_STRUKTURY_H

struct ss{
    double x;
    double y;
};
struct t{
    double x;
    double y;
};

#endif // MOJE_STRUKTURY_H
