#include <iostream>
#include <vector>



struct ss{
    double x;
    double y;
};
struct t{
    double x;
    double y;
};

void vypocet_teziste(std::vector <ss> SS, t T);

int main()
{
    std::vector <ss> SS={ss{10,5},ss{-6,-1},ss{-5,2}};
    t T;

    vypocet_teziste(SS,T);

    std::cout<<"souradnice Teziste x:"<<T.x<<" y: "<<T.y<<std::endl;
}

void vypocet_teziste(std::vector <ss> SS, t &T){
    int poc=SS.size();
    for (int i=0;i<poc;i++){
        T.x+=SS[i].x;
        T.y+=SS[i].y;
    }
    T.x=T.x/poc;
    T.y=T.y/poc;
}



