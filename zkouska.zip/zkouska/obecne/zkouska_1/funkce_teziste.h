#ifndef FUNKCE_TEZISTE_H
#define FUNKCE_TEZISTE_H
#include "moje_struktury.h"

#include <iostream>
#include <vector>
void vypocet_teziste(std::vector <ss> SS, t T);

#endif // FUNKCE_TEZISTE_H
