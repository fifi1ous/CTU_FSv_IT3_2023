#include <iostream>
#include <vector>


int main()
{
    std::vector <int> B;
    int t;
    while (std::cin>>t){
        B.push_back(t);
    }

    int a=B.size();
    int pom;
    for (int i=0;i<a-1;i++){
        for (int j=0;j<a-i;j++){
            if(B[j]>B[j+1]){
                pom=B[j];
                B[j]=B[j+1];
                B[j+1]=pom;
            }
        }
    }

    for (int i=0;i<a;i++){
        std::cout<<B[i]<<std::endl;
    }
}
