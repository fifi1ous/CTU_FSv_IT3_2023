#include <iostream>
#include<suda_licha.h>

//void suda_licha(int x);
int x;

int main()
{
std::cout<<"Napiste cislo: ";
std::cin>>x;

/*if (x%2==0){
    std::cout<<"Cislo "<<x<<" je sude"<<std::endl;
}else{
    std::cout<<"Cislo "<<x<<" je liche"<<std::endl;
}*/

suda_licha(x);

}

/*void suda_licha(int x){
    if (x%2==0){
        std::cout<<"Cislo "<<x<<" je sude"<<std::endl;
    }else{
        std::cout<<"Cislo "<<x<<" je liche"<<std::endl;
    }
}*/
