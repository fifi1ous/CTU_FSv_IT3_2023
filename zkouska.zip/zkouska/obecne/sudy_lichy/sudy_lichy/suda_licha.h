#ifndef SUDA_LICHA_H
#define SUDA_LICHA_H

#include <iostream>

void suda_licha(int x);

#endif // SUDA_LICHA_H
