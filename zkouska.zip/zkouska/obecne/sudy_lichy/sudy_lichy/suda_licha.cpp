#include<suda_licha.h>
#include <iostream>

void suda_licha(int x){
    if (x%2==0){
        std::cout<<"Cislo "<<x<<" je sude"<<std::endl;
    }else{
        std::cout<<"Cislo "<<x<<" je liche"<<std::endl;
    }
}

