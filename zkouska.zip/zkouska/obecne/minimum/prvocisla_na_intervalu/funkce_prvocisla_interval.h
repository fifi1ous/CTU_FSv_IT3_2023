#ifndef FUNKCE_PRVOCISLA_INTERVAL_H
#define FUNKCE_PRVOCISLA_INTERVAL_H

#include <iostream>
#include <vector>
void prvocisla(std::vector <int> x, std::vector <int> &y,int &min,int &max);

#endif // FUNKCE_PRVOCISLA_INTERVAL_H
