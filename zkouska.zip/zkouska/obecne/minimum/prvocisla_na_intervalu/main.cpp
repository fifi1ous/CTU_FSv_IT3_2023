#include <iostream>
#include <vector>
#include "funkce_prvocisla_interval.h"

//void prvocisla(std::vector <int> x, std::vector <int> &y,int &min,int &max);

int main()
{
    std::vector <int> x;
    std::vector <int> y;
    int min;
    int max;
    int z;
    std::cout<<"Zadejte cisla intervalu"<<std::endl;
    for (int i=0;i<=1;i++){
        std::cin>>z;
        x.push_back(z);
    }


    /*if (x[0]<=x[1]){
        min=x[0];
        max=x[1];
    }else{
        min=x[1];
        max=x[0];
    }

    std::vector <int> y;
    for (min;min<=max;min++){
        for (int i=2;i<=min/2;i++){
            if (min%i==0){
                t=0;
            }
        }
        if(t){
           y.push_back(min);
        }else{
        t=1;
        }
    }*/

    prvocisla(x,y,min,max);

    std::cout<<"Prvocisla na intervalu "<<min<<" "<<max<<std::endl;
    for (int i=0; i<y.size();i++){
        std::cout<<y[i]<<" ";
    }
    std::cout<<std::endl;

}

/*void prvocisla(std::vector <int> x, std::vector <int> &y,int &min,int &max){
    int t=1;
    int min2,max2;

    if (x[0]<=x[1]){
        min=x[0];
        max=x[1];
    }else{
        min=x[1];
        max=x[0];
    }
    min2=min;
    max2=max;

    for (min2;min2<=max2;min2++){
        for (int i=2;i<=min2/2;i++){
            if (min2%i==0){
                t=0;
            }
        }
        if(t){
           y.push_back(min2);
        }else{
        t=1;
        }
    }
}*/
