#include "funkce_prvocisla_interval.h"
#include <iostream>
#include <vector>

void prvocisla(std::vector <int> x, std::vector <int> &y,int &min,int &max){
    int t=1;
    int min2,max2;

    if (x[0]<=x[1]){
        min=x[0];
        max=x[1];
    }else{
        min=x[1];
        max=x[0];
    }
    min2=min;
    max2=max;

    for (min2;min2<=max2;min2++){
        for (int i=2;i<=min2/2;i++){
            if (min2%i==0){
                t=0;
            }
        }
        if(t){
           y.push_back(min2);
        }else{
        t=1;
        }
    }
}
