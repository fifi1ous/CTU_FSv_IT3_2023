#include <funkce_vyh_min_ind.h>
#include <funkce_vzdalenost.h>
#include <iostream>
#include <vector>
#include <cmath>

double nejkratsi_vzdal(std::vector <BOD> SS, int& indA, int& indB){
    double min_vzd=10e6;
    int poc=SS.size();
    for (int i=0; i<poc-1;i++){
        for (int j=i+1;j<poc-1;j++){
            double vzd=vzdalenost_bodu(SS[i],SS[j]);
            if (vzd<min_vzd){
                min_vzd=vzd;
                indA=i+1;
                indB=j+1;
            }
        }
    }
    return min_vzd;
}
