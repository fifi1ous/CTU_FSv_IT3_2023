#ifndef FUNKCE_VZDALENOST_H
#define FUNKCE_VZDALENOST_H

#include <iostream>
#include <vector>
#include <cmath>

struct BOD{
    double x;
    double y;
    double z;
};

double vzdalenost_bodu(BOD a,BOD b);

#endif // FUNKCE_VZDALENOST_H
