#include <iostream>
#include <vector>
#include <cmath>
#include <funkce_vzdalenost.h>

double vzdalenost_bodu(BOD a,BOD b){
    return std::sqrt((a.x-b.x)*(a.x-b.x)+
                     (a.y-b.y)*(a.y-b.y)+
                     (a.z-b.z)*(a.z-b.z) );
}
