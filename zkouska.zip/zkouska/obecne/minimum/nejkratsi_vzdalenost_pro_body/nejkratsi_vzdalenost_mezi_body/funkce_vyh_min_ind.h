#ifndef FUNKCE_VYH_MIN_IND_H
#define FUNKCE_VYH_MIN_IND_H

#include <iostream>
#include <funkce_vzdalenost.h>
#include <vector>
#include <cmath>



double nejkratsi_vzdal(std::vector <BOD> SS, int& indA, int& indB);

#endif // FUNKCE_VYH_MIN_IND_H
