#include <iostream>
#include <vector>
#include <cmath>
#include <funkce_vzdalenost.h>
#include <funkce_vyh_min_ind.h>

//nejkratsi vzdalenost mezi body

/*struct BOD{
    double x;
    double y;
    double z;
};*/

//double vzdalenost_bodu(BOD a,BOD b);
//double nejkratsi_vzdal(std::vector <BOD> SS, int& indA, int& indB);

int main()
{
    BOD b1 ={0.0,2.0,0.0};
    BOD b2 ={-2000.0,1200.0,30.0};
    BOD b3 ={7.0,6.0,-1.0};
    BOD b4 ={-160.0,-100.0,0.0};
    std::vector <BOD> SS={b1,b2,b3,b4};


    int indA,indB;
    double min_vzd=nejkratsi_vzdal(SS, indA, indB);

    std::cout<<"Nejkratsi vzdalenost mezi dvema body je: "<<min_vzd<<"\nVzdalenost je mezi body c: "<<indA<<" a "<<indB<<std::endl;
}

/*double vzdalenost_bodu(BOD a,BOD b){
    return std::sqrt((a.x-b.x)*(a.x-b.x)+
                     (a.y-b.y)*(a.y-b.y)+
                     (a.z-b.z)*(a.z-b.z) );
}*/

/*double nejkratsi_vzdal(std::vector <BOD> SS, int& indA, int& indB){
    double min_vzd=10e6;
    int poc=SS.size();
    for (int i=0; i<poc-1;i++){
        for (int j=i+1;j<poc-1;j++){
            double vzd=vzdalenost_bodu(SS[i],SS[j]);
            if (vzd<min_vzd){
                min_vzd=vzd;
                indA=i+1;
                indB=j+1;
            }
        }
    }
    return min_vzd;
}*/
