#include <iostream>
#include <vector>
#include <string>

struct BOD{
    std::string nazev;
    double x;
    double y;
    double z;
    double R;
};
int poc;
int j;
std::string prom;

int main()
{
std::cout<<"Napiste pocet planet v seznamu: "<<std::endl;
std::cin>>poc;
std::vector <BOD> SS(poc);
for (int i=0;i<poc;i++){
    std::cout<<"Planeta cislo: "<<++i<<" [Nazev, x, y, z, R]"<<std::endl;
    std::cin>>SS[--i].nazev;
    std::cin>>SS[i].x;
    std::cin>>SS[i].y;
    std::cin>>SS[i].z;
    std::cin>>SS[i].R;
}

std::cout<<"Kolikatou planetu v seznamu chcete vypsat 1-"<<poc<<": ";
std::cin>>j;
std::cout<<std::endl;
std::cout<<"Nazev: "<<SS[j-1].nazev<<" x: "<<SS[j-1].x<<" y: "<<SS[j-1].y<<" z: "<<SS[j-1].z<<" R: "<<SS[j-1].R<<std::endl;

std::cout<<"Zadejte nazev planety co chcete vyhledat: ";
std::cin>>prom;
for(int i=0;i<poc;i++){
    if (prom==SS[i].nazev){
        std::cout<<"x: "<<SS[i].x<<" y: "<<SS[i].y<<" z: "<<SS[i].z<<" R: "<<SS[i].R<<std::endl;
    }
}
}
