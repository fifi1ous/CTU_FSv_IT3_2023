#ifndef FUNKCE_MINIMUM_H
#define FUNKCE_MINIMUM_H

#include <iostream>
#include <vector>
int min_vektoru(std::vector <int> x);

#endif // FUNKCE_MINIMUM_H
