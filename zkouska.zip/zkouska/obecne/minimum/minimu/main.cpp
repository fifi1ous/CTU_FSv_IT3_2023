#include <iostream>
#include <vector>
#include "funkce_minimum.h"

//nejmenší číslo ve vektoru

int poc;
int i;

//int min_vektoru(std::vector <int> x);

int main()
{
std::cout<<"Kolik prvku ma vektor:"<<std::endl;
std::cin>>poc;
std::vector<int>x(poc);
std::cout<<"Napiste cisla ktere jsou ve vektoru:"<<std::endl;
for(i=0;i<=poc-1;i++){
    std::cin>>x[i];
}

/*
int min=x[0];
for(i=1;i<=poc-1;i++){
    if (x[i]<min){
        min=x[i];
    }

}
*/

std::cout<<"Nejmensi cislo vektoru: "<<std::endl;
std::cout<<min_vektoru(x)<<std::endl;
}

/*
int min_vektoru(std::vector <int> x){
    int min=x[0];
    for(i=1;i<=poc-1;i++){
        if (x[i]<min){
            min=x[i];
        }

    }
    return min;
}
*/
