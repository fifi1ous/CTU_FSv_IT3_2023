#include "funkce_minimum.h"
#include <iostream>
#include <vector>

int min_vektoru(std::vector <int> x){
    int min=x[0];
    int poc=x.size();
    for(int i=1;i<=poc-1;i++){
        if (x[i]<min){
            min=x[i];
        }

    }
    return min;
}
