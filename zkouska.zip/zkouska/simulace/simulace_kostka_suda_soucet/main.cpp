#include <iostream>
#include <ctime>
#include <cstdlib>

int hod_kostkou(){
    return 1.0+6*rand()/(1.0+RAND_MAX);
}

bool Je_soucet_sudy(){
    int sum=0;
    for (int i=1;i<=3;i++){
        sum+=hod_kostkou();
    }
    if (sum%2==0){
        return true;
    }else{
        return false;
    }
}

int main()
{
    int pocet=10e6;
    int uspech=0;
    for (int i=1;i<=pocet;i++){
        if (Je_soucet_sudy()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost, ze soucet 3 kostek sudy je "<<1.0*uspech/pocet<<std::endl;
}
