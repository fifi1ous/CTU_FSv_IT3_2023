#include <iostream>
#include <ctime>
#include <cstdlib>

int tahnu_kartu(){
    return 32*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int poc, int pod2){
    int podminka;
    int pod=1;
    int tah=tahnu_kartu();
    if (pod2){
        podminka=tah/8;
    }else{
        podminka=0;
    }
    for (int j=1;j<=poc;j++){
        if (tah/8==podminka){
        }else{
            pod=0;
        }
        tah=tahnu_kartu();
    }
    return pod;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    int poc=1;
    int pod=0;
    for (int i=1;i<=pocet;i++){
        if(simuluj(poc,pod)){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze vytahnu "<<poc<<"x kartu se stejnou barvou s vracenim "<<1.0*uspech/pocet<<std::endl;
}
