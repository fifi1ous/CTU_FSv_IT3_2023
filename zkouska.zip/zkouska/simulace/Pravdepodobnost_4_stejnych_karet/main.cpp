#include <iostream>
#include <ctime>
#include <cstdlib>

int tahnu_kartu(){
    return 1+32*(rand()/(1.0+RAND_MAX));
}

bool vythnu_4_stejne_karty(){

}

int main()
{
    int pocet=10e6;
    int uspech=0;
    for (int i=1;i<10e6;i++){

    }
}
