#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

int poc;

int tahnu_kartu(){
    return 1.0+32*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int poc){
    std::vector <int> x(poc);
    for (int j=0;j<=poc-1;j++){
        x[j]=tahnu_kartu();
    }
    for (int j=1;j<=poc-1;j++){
        if (x[0]!=x[j]){
            return false;
        }
    }
    return true;
}

int main()
{
    std::cout<<"Kolikrat budu tahnout kartu: ";
    std::cin>>poc;
    std::cout<<std::endl;
    int pocet=10e6;
    int uspech=0;
    for (int i=1;i<=pocet;i++){
        if (simuluj(poc)){
            uspech++;
        }
    }
    std::cout<<"Pravdepodonost ze kdyz "<<poc<<"x tahnu kartu s vracenim, tak vytahnu stejnou kartu: "<<1.0*uspech/pocet<<std::endl;
}
