#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>
#include <string.h>

int tahnu_kartu(){
    return 1+32*rand()/(1.0+RAND_MAX);
}

bool simuluj(int poc1,int poc2){
    std::vector <bool> karty(32, false);

    for (int poc=1;poc<=poc1;poc++){
        int karta=tahnu_kartu();

        while (karty[karta-1]==true) {
            karta=tahnu_kartu();
        }
        karty[karta-1]=true;
    }

    int pocet=0;
    for (int i=0;i<poc2;i++){
        if(karty[i]==true){
            pocet++;
        }
    }

    return(pocet==poc1);
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    int poc=1;      //pocet karet co tahnu
    int poc1=4;     //pocet karet čtveřice/osmice
    for (int i=1;i<pocet;i++){
        if (simuluj(poc,poc1)){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze vythnu "<<poc<<" stejne karty bez vraceni: "<<1.0*uspech/pocet<<std::endl;
}
