#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

int hod_kostkou(){
    return 1+6*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int pocet){
    std::vector <bool> x(6, false);

    for(int j=1;j<=pocet;j++){
        int hod=hod_kostkou();
        x[hod-1]=true;
    }

    if(x[0]&&x[1]&&x[2]&&x[3]&&x[4]&&x[5]){
        return true;
    }else{
        return false;
    }
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    int pocet_kostek=0;
    double pravd=0;

    while(pravd<=0.50){
        for (int i=1;i<=pocet;i++){
            if (simuluj(pocet_kostek)){
                uspech++;
            }
        }
        std::cout<<"Pravdepodobnost ze padne kazde cislo: "<<1.0*uspech/pocet<<" pocet kostek: "<<pocet_kostek<<std::endl;
        pravd=1.0*uspech/pocet;
        uspech=0;
        pocet_kostek++;
    }

}
