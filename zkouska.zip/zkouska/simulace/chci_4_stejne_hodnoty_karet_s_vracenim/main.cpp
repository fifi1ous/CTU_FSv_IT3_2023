#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>

int tahnu_kartu(){
    return 32*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int poc,int konkr){
    int sum=0;
    int hod;
    int interval,start;

    hod=tahnu_kartu();
    if (konkr){
        start=1;
    }else {
        interval=hod%4;
        start=hod-interval;
    }
    std::vector <int> B={start,++start,++start,++start};
    for (int j=1;j<=poc;j++){
        if (hod==B[0]||hod==B[1]||hod==B[2]||hod==B[3]){
            sum+=1;
        }
        hod=tahnu_kartu();
    }
    if (sum==poc){
        return true;
    }else{
        return false;
    }
}

int main()
{
   int poc=2;
   int konkr=1;
   int pocet=10e6;
   int uspech=0;
   for (int i=1;i<=pocet;i++){
       if (simuluj(poc,konkr)){
           uspech++;
       }
   }
   std::cout<<"Tahnu "<<poc<<"x kartu jaka je pravdepodobnost, ze budu mit stejnou hodnotu, karty vracim :"<<(1.0*uspech/pocet)<<std::endl;
}
