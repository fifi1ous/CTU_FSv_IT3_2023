#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int strili(){
    return 1+10*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int uspech=0;
    if (strili()<=7){
        uspech++;
    }
    if (strili()<=8){
        uspech++;
    }
    if (strili()<=9){
        uspech++;
    }

    if (uspech>=1){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech =0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze trefi, alepson jednou terc je "<<1.0*uspech/pocet<<std::endl;
}
