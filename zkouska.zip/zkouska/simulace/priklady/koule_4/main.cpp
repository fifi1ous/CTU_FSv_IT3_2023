#include <iostream>
#include <ctime>
#include <cstdlib>

int tahnu(int ck){
    return 1.0+(20+ck)*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int ck){
    if (tahnu(ck)>20){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    int ck=0;
    double pravd=0;
    while(pravd<=0.20){
        for (int i=0;i<pocet;i++){
            if(simuluj(ck)){
                uspech++;
            }
        }
        pravd=1.0*uspech/pocet;
        std::cout<<"pocet kouli: "<<ck<<" pravdepobnost: "<<pravd<<std::endl;
        ck++;
        uspech=0;
    }
}
