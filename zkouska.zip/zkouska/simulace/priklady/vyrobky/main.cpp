#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int tahnu(){
    return  1+49*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector<bool> x(49);

    for (int i=0;i<6;i++){
        int vyr=tahnu();

        while (x[vyr-1]){
            vyr=tahnu();
        }

        x[vyr-1]=true;
    }

    int pocet=0;
    for (int i=0;i<6;i++){
        if (x[i]){
            pocet++;
        }
    }

    if(pocet>=4){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze alespon 4 jsou dobre je:"<<1.0*uspech/pocet<<std::endl;
}
