#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int hod(){
    return 1+6*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int p_kostek){
    std::vector<bool>x(6,false);

    for (int i=1;i<=p_kostek;i++){
        x[hod()-1]=true;
    }

    if(x[0]&&x[1]&&x[2]&&x[3]&&x[4]&&x[5]){
        return true;
    }
    return false;
}

using namespace std;

int main(){
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    int p_kostek=0;
    double pravd=0;
    while (pravd<0.50){
        for (int i=0;i<pocet;i++){
            if (simuluj(p_kostek)){
                uspech++;
            }
        }
        pravd=1.0*uspech/pocet;
        std::cout<<"Pocet kostek: "<<p_kostek<<" Pravdepodobnost ze kazde cislo padne minimalne 1: "<<pravd<<std::endl;
        uspech=0;
        p_kostek++;
    }
 }
