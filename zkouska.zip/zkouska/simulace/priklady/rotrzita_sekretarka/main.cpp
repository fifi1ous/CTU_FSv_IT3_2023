#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int vlozeni(){
    return 3*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector <int> x(3,4);

    for (int i=0;i<3;i++){
        int y1=vlozeni();

        while (x[0]==y1||x[1]==y1||x[2]==y1){
            y1=vlozeni();
        }

        x[i]=y1;
    }
    if (x[0]==0||x[1]==1||x[2]==2){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost, ze alespon jeden adresat dostane spravny list je: "<<1.0*uspech/pocet<<std::endl;
}
