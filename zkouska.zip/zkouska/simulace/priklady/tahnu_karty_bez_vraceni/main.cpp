#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int tah(){
    return 1+32*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector <bool> x(32, false);

    for (int i=0;i<7;i++){
        int karta=tah();

        while (x[karta-1]==true){
            karta=tah();
        }

        x[karta-1]=true;
    }
    int poc=0;
    for (int i=0;i<8;i++){
        if(x[i]){
            poc++;
        }
    }
    if (poc==3){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet =1e6;
    int uspech=0;
    for (int i = 1;i<=pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze kdyz vytahneme 7 karet, tak ze mezi nimi budou 3 srdce je: "<<1.0*uspech/pocet<<std::endl;
}
