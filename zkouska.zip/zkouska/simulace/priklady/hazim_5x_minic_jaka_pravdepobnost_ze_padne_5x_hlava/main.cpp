#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int hod(){
    return 2*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int p=0;
    for (int i=1;i<=5;i++){
        p+=hod();
    }
    if(p==5){
        return true;
    }else{
        return false;
    }
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if(simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobno ze na minci 5x po sobe padne hlava je: "<<1.0*uspech/pocet<<std::endl;
}
