#include <iostream>
#include <ctime>
#include <cstdlib>

int hod(){
    return 1+6*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    if ((hod()+hod())>3){
        return true;
    }else{
        return false;
    }
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=1;i<=pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze na dvou kostkach padne dohromady cislo vesti nez 3 je :"<<1.0*uspech/pocet<<std::endl;
}
