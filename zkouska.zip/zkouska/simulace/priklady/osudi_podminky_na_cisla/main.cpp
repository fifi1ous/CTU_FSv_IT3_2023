#include <iostream>
#include <ctime>
#include <cstdlib>

int generuj_cislo(){
    return 1+100*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int vys=generuj_cislo();
    if (vys%2==0||vys%5==0){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i =0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost, ze kdyz cislo od 1-100, bude delitelne 2 a 5 je: "<<1.0*uspech/pocet<<std::endl;
}
