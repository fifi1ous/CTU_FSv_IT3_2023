#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int vyber_hrnec(){
    return 1+10*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector <int> x(10,false);

    for (int i=0;i<2;i++){
        int y=vyber_hrnec();

        while(x[y-1]){
            y=vyber_hrnec();
        }
        x[y-1]=true;
    }
    int vad=0;
    for (int i=0;i<2;i++){
        if (x[i]){
            vad++;
        }
    }
    if (vad>=1){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if(simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze vybere, alepson jeden vadny hrnec je: "<<1.0*uspech/pocet<<std::endl;
}
