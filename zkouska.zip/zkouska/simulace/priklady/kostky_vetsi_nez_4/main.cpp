#include <iostream>
#include <ctime>
#include <cstdlib>

int hod(){
    return 1+6*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    if (hod()>4){
        return true;
    }else{
        return false;
    }
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=1;i<=pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<" Pravdepodobnost ze padne cislo vetsi ne 4 je: "<<1.0*uspech/pocet<<std::endl;
}
