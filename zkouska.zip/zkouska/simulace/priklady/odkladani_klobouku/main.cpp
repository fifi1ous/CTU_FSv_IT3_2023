#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int vybiram(){
    return 4*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector<int> x(4,5);

    for (int i=0;i<4;i++){
        int klobouk=vybiram();

        while (x[0]==klobouk||x[1]==klobouk||x[2]==klobouk||x[3]==klobouk){
            klobouk=vybiram();
        }

        x[i]=klobouk;
    }

    if (x[0]==0||x[1]==1||x[2]==2||x[3]==3){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze, alespon jeden odejde se svym kloboukem je: "<<1.0*uspech/pocet<<std::endl;
}
