#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int narozeniny(){
    return 1+365*(rand()/(1.0+RAND_MAX));
}

bool simuluj(int lid){
    std::vector <int> x(365,0);

    for (int i=1; i<=lid;i++){
        int datum=narozeniny();
        x[datum-1]++;

        if (x[datum-1]>1){
            return true;
        }
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    double pravd=0;
    int lid=0;
    while (pravd<=0.50){
        for (int i=0;i<pocet;i++){
            if (simuluj(lid)){
                uspech++;
            }
        }
        pravd=1.0*uspech/pocet;
        std::cout<<"Pravdepodobnost ze "<<lid<<" lidi bude mit ve stejny den narozeniny je "<<pravd<<std::endl;
        uspech=0;
        lid++;
    }
}
