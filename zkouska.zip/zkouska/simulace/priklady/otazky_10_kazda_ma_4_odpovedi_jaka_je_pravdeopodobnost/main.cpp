#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int odpoved_na_otazku(){
    return 1+4*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int spravne=0;
    for (int i=0;i<10;i++){
        if(odpoved_na_otazku()==1){
            spravne++;
        }
    }
    if (spravne>=5){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze 10 otazek odpovi minilane 5x spravne je: "<<1.0*uspech/pocet<<std::endl;
}
