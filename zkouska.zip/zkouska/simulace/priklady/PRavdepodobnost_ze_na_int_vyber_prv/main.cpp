#include <iostream>
#include <ctime>
#include <cstdlib>

int tahnu(){
    return 1+20*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int cislo=tahnu();
    int pom=0;
    if (cislo==1){
        return false;
    }
    for (int i=2;i<=cislo/2;i++){
        if (cislo%i==0){
            pom++;
        }
    }
    if (pom==0){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze vytahne cislo co je prvocislo je :"<<1.0*uspech/pocet<<std::endl;
}
