#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int vybiram(){
    return 1+7*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector <int> x(3);
    for (int i=0;i<3;i++){
        int z=vybiram();

        while(i==0&&z==1){
            z=vybiram();
        }

        x[i]=z;
    }

    if(x[0]==4&&x[1]==4&&x[2]==5){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze vytvorime cislo 445 je:"<<1.0*uspech/pocet<<std::endl;
}

