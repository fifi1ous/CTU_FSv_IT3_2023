#include <iostream>
#include <ctime>
#include <cstdlib>
#include <vector>

int beru_soucastku(){
    return 1+800*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    std::vector<bool> x(800,false);

    for (int i=0;i<9;i++){
        int soucastka=beru_soucastku();

        while(x[soucastka-1]){
            soucastka=beru_soucastku();
        }

        x[soucastka-1]=true;
    }


    int poc=0;

    for (int i=0;i<9;i++){
        if (x[i]){
            poc++;
        }
    }

    if (poc<3){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i=0;i<pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze kdyz z 800 soucastek vyberu nahodne 9, tak jich bude vadnych vic nez 3:"<<1.0*uspech/pocet<<std::endl;
}
