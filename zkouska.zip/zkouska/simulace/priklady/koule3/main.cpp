#include <iostream>
#include <ctime>
#include <cstdlib>

int tahnu(){
    return 1+14*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int barva=0;
    for (int i=0;i<2;i++){
        if(tahnu()>5){
            barva++;
        }
    }
    if (barva==1){
        return true;
    }
    return false;
}

int main()
{
    srand(time(0));
    int pocet=1e6;
    int uspech=0;
    for (int i =0;i<pocet;i++){
        if(simuluj()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze 2 nebudou stejne je :"<<1.0*uspech/pocet<<std::endl;
}
