#include <iostream>
#include <ctime>
#include <cstdlib>

/*int vyberu(){
    return 1+19*(rand()/(1.0+RAND_MAX));
}*/

int main()
{
    //srand(time(0));

}
