#include <iostream>
#include <ctime>
#include <cstdlib>

//karty na prší


int tahnu_kartu(){
    return 1.0+32*(rand()/(1.0+RAND_MAX));
}

bool simuluj(){
    int karta1=tahnu_kartu();
    int karta2=tahnu_kartu();

    if (karta1==karta2){
        return true;
    }else{
        return false;
    }
}
int main()
{
    int pocet=10e6;
    int uspech=0;
    for (int i=1;i<=pocet;i++){
        if (simuluj()){
            uspech++;
        }
    }
    std::cout<<" Pravdepodobnost, ze vytahnu 2 stejne po sobe je: "<<1.0*uspech/pocet<<std::endl;
}
