#include <iostream>
#include <ctime>
#include <cstdlib>


int hod_kostkou(){
    return 1.0+6*(rand()/(1.0+RAND_MAX));
}

bool je_cislo_sude(){
    if (hod_kostkou()%2==0){
        return true;
    }else{
        return false;
    }
}

int main()
{
    srand(time(0));
    int uspech=0;
    int pocet=10e7;
    for (int i=0;i<=pocet;i++){
        if (je_cislo_sude()){
            uspech++;
        }
    }
    std::cout<<"Pravdepodobnost ze padne sude cislo je: "<<(uspech*1.0)/pocet<<std::endl;
}
